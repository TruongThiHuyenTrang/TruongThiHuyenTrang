﻿using DevExpress.Utils.Gesture;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static DevExpress.Utils.Svg.CommonSvgImages;

namespace CJ_HSDT_ADMIN
{
    public partial class Thearter1 : Form
    {
        public Thearter1()
        {
            InitializeComponent();
        }

        private void btnScreen_Click(object sender, EventArgs e)
        {
            dataGridView1.Columns.Clear();
            dataGridView1.BackgroundColor = Color.Black;
            //dataGridView1.;
            int i, j;
            int dong = Int32.Parse(txtDong.Text) + 1;
            int cot =  Int32.Parse(txtCot.Text) + 1;
            int HIGHT = 27;

            DataGridViewCheckBoxColumn doWork = new DataGridViewCheckBoxColumn();
            //  doWork.HeaderText = "Include Dog";
            doWork.FalseValue = "0";
            doWork.TrueValue = "1";
            dataGridView1.Columns.Insert(0, doWork);
            dataGridView1.Rows.Add(dong);
            for (i = 1; i < cot; i++)
            {
                dataGridView1.Columns.Add("dong" + i.ToString(), "");
                dataGridView1.Columns[i].Width = HIGHT;
            }

            for (i = 0; i < dong; i++) dataGridView1.Rows[i].Height = HIGHT;

            for (i = 1; i < dong; i++) dataGridView1.Rows[i].Cells[0].Value = true;
            for (i = 1; i < cot; i++) dataGridView1.Rows[0].Cells[i].Value = "v";

            for (i = 1; i < dong; i++)
                for (j = 1; j < cot; j++) dataGridView1.Rows[i].Cells[j].Value = j;
        }

        private void dataGridView1_Paint(object sender, PaintEventArgs e)
        {


        }

        private void dataGridView1_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            /*      if (e.RowIndex == -1||e.ColumnIndex ==-1 ) // Kiểm tra dòng tiêu đề và cột đầu tiên
                  {
                      e.PaintBackground(e.CellBounds, true);
                      e.PaintContent(e.CellBounds);

                      var checkboxRect = new Rectangle(e.CellBounds.X + 2, e.CellBounds.Y + 2, 18, 18);
                      ControlPaint.DrawCheckBox(e.Graphics, checkboxRect, ButtonState.Checked);

                      e.Handled = true;
                  }*/
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            Color maunen;

            if (e.RowIndex == 0 && e.ColumnIndex > 0) //Chon cot
            {
                if (!(dataGridView1.Rows[0].Cells[e.ColumnIndex].Value is null|| dataGridView1.Rows[0].Cells[e.ColumnIndex].Value==""))//Xoa
                {
                    maunen = Color.White;
                    dataGridView1.Rows[0].Cells[e.ColumnIndex].Value = "";
                }
                else
                {
                    maunen = Color.Black;
                    dataGridView1.Rows[0].Cells[e.ColumnIndex].Value = "v";
                }
                for (i = 1; i < dataGridView1.ColumnCount; i++)
                    dataGridView1.Rows[i].Cells[e.ColumnIndex].Style.BackColor = maunen;
            }

            else if (e.ColumnIndex == 0 && e.RowIndex > 0)//Chon dong
            {
                DataGridViewCheckBoxCell checkedCell = (DataGridViewCheckBoxCell)dataGridView1.Rows[e.RowIndex].Cells[0];
                if (!checkedCell.AccessibilityObject.State.HasFlag(AccessibleStates.Checked))
                {
                    dataGridView1.Rows[e.RowIndex].Cells[0].Value = true;
                    maunen = Color.Black;
                }
                else
                {
                    dataGridView1.Rows[e.RowIndex].Cells[0].Value = false;
                    maunen = Color.White;
                }
                for (i = 1; i < dataGridView1.RowCount; i++)
                    dataGridView1.Rows[e.RowIndex].Cells[i].Style.BackColor = maunen;
            }

        }

    }


}
