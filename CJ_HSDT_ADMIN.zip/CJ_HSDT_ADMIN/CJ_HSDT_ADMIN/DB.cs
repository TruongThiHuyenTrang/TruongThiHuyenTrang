﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace CJ_HSDT_ADMIN
{
    public class DB
    {
        static SqlConnection cnn;
        public static bool adminLogin;
        public static void DBConnect()
        {
            cnn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog= dbCjHSDT;Integrated Security=True");
            try
            {
                cnn.Open();
            }
            catch (Exception)
            {

                throw;
            }
            
        }
        public static void DBClose()
        {
            cnn.Close();
        }
        public static DataTable getDataToGrid(string que)
        {
            DBConnect();
            DataTable tb = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(que,cnn);
            da.Fill(tb);
            DBClose();
            return tb;
        }
        public static string  Get1String(string que)
        {
            SqlCommand cmd = new SqlCommand(que, cnn);
            var kq = cmd.ExecuteScalar();
            string s = "";
            if (kq != null) s = kq.ToString();
            cmd.Clone();
            return s;
        }
        public static SqlDataReader GetData(string que)
        {
            SqlCommand cmd = new SqlCommand(que, cnn);
            SqlDataReader kq = cmd.ExecuteReader();
            cmd.Clone();
            return kq;
        }

    }
}
