﻿namespace CJ_HSDT_ADMIN
{
    partial class fMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labMovies = new System.Windows.Forms.Label();
            this.labTimeTable = new System.Windows.Forms.Label();
            this.labThearter = new System.Windows.Forms.Label();
            this.picright = new System.Windows.Forms.PictureBox();
            this.picleft = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.picright)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picleft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // labMovies
            // 
            this.labMovies.AutoSize = true;
            this.labMovies.Font = new System.Drawing.Font("Candara", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labMovies.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(112)))), ((int)(((byte)(97)))));
            this.labMovies.Location = new System.Drawing.Point(809, 153);
            this.labMovies.Name = "labMovies";
            this.labMovies.Size = new System.Drawing.Size(108, 33);
            this.labMovies.TabIndex = 1;
            this.labMovies.Text = "MOVIES";
            this.labMovies.Click += new System.EventHandler(this.labMovies_Click);
            // 
            // labTimeTable
            // 
            this.labTimeTable.AutoSize = true;
            this.labTimeTable.Font = new System.Drawing.Font("Candara", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labTimeTable.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(112)))), ((int)(((byte)(97)))));
            this.labTimeTable.Location = new System.Drawing.Point(527, 153);
            this.labTimeTable.Name = "labTimeTable";
            this.labTimeTable.Size = new System.Drawing.Size(153, 33);
            this.labTimeTable.TabIndex = 2;
            this.labTimeTable.Text = "TIME TABLE";
            this.labTimeTable.Click += new System.EventHandler(this.labTimeTable_Click);
            // 
            // labThearter
            // 
            this.labThearter.AutoSize = true;
            this.labThearter.Font = new System.Drawing.Font("Candara", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labThearter.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(112)))), ((int)(((byte)(97)))));
            this.labThearter.Location = new System.Drawing.Point(228, 153);
            this.labThearter.Name = "labThearter";
            this.labThearter.Size = new System.Drawing.Size(138, 33);
            this.labThearter.TabIndex = 3;
            this.labThearter.Text = "THEARTER";
            this.labThearter.Click += new System.EventHandler(this.labThearter_Click);
            // 
            // picright
            // 
            this.picright.Image = global::CJ_HSDT_ADMIN.Properties.Resources.RIGHT;
            this.picright.Location = new System.Drawing.Point(1009, 361);
            this.picright.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picright.Name = "picright";
            this.picright.Size = new System.Drawing.Size(159, 138);
            this.picright.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picright.TabIndex = 2;
            this.picright.TabStop = false;
            this.picright.Click += new System.EventHandler(this.picright_Click);
            // 
            // picleft
            // 
            this.picleft.Image = global::CJ_HSDT_ADMIN.Properties.Resources.LEFT;
            this.picleft.Location = new System.Drawing.Point(39, 361);
            this.picleft.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picleft.Name = "picleft";
            this.picleft.Size = new System.Drawing.Size(159, 138);
            this.picleft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picleft.TabIndex = 2;
            this.picleft.TabStop = false;
            this.picleft.Click += new System.EventHandler(this.picleft_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CJ_HSDT_ADMIN.Properties.Resources.BADGIRL;
            this.pictureBox2.Location = new System.Drawing.Point(431, 222);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(389, 469);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CJ_HSDT_ADMIN.Properties.Resources.Logo;
            this.pictureBox1.Location = new System.Drawing.Point(415, 42);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(383, 89);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // fMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1203, 704);
            this.Controls.Add(this.picright);
            this.Controls.Add(this.picleft);
            this.Controls.Add(this.labMovies);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.labThearter);
            this.Controls.Add(this.labTimeTable);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "fMain";
            this.Text = "fMain";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.fMain_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.picright)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picleft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labMovies;
        private System.Windows.Forms.Label labTimeTable;
        private System.Windows.Forms.Label labThearter;
        private System.Windows.Forms.PictureBox picright;
        private System.Windows.Forms.PictureBox picleft;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Timer timer1;
    }
}