﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CJ_HSDT_ADMIN
{
    public partial class fLogin : Form
    {
        public fLogin()
        {
            InitializeComponent();
            DatGiaoDien();
        }

        void DatGiaoDien()
        {
            BackColor = Color.FromArgb(242, 240, 229);
            List<Control> list = new List<Control>();

            foreach (Control control in Controls)
            {
                if (control.GetType() == typeof(Button))
                {
                    control.BackColor = Color.FromArgb(100, 221, 136);
                    
                }

            }
            Font = new Font("Candara",16,FontStyle.Bold);
            StartPosition= FormStartPosition.CenterScreen;
       
        }

        private void bLogin_Click(object sender, EventArgs e)
        {
            DB.DBConnect();
            string pass = DB.Get1String("Select top 1 pwd from tblUsers where isAdmin =1 and uid = '" +
                txtUserName.Text + "'");
            if (pass != "")
            {
                if (pass == txtPassWord.Text) //Connect Thanh Cong
                {

                    this.Hide();
                    fMain fMain = new fMain();
                    fMain.Show();


                }
                else
                {
                    MessageBox.Show("Sai mật khẩu");
                }
            }
            else
            {
                MessageBox.Show("Sai tên đăng nhập");
            }
            DB.DBClose();

        }
    }
}
