﻿using DevExpress.Internal.WinApi.Windows.UI.Notifications;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CJ_HSDT_ADMIN
{
    public partial class fMain : Form
    {
        List<String> list = new List<String>();
        int Index =0;
        public fMain()
        {
            InitializeComponent();
            DatGiaoDien();
            LoadListAnh();
            timer1.Start();
        }
        void LoadListAnh()
        {
            SqlDataReader kq = DB.GetData("Select top 10 name from tblMovies order by id DESC");
            string s;
            while (kq.Read())
            {
                s = kq.GetString(0);
                s = s.Replace(" ", "");
                list.Add(s);
            }
            
        }
        void DatGiaoDien()
        {
            BackColor = Color.FromArgb(242, 240, 229);
         //   panelControl3.Font = new Font("Candara", 12, FontStyle.Bold);
            StartPosition = FormStartPosition.CenterScreen;

        }

        private void panelControl2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelControl3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void labThearter_Click(object sender, EventArgs e)
        {
            Thearter1 thearter = new Thearter1();
            thearter.Show();
        }

        private void labTimeTable_Click(object sender, EventArgs e)
        {
            Timetable theetable = new Timetable();
            theetable.Show();
        }

        private void labMovies_Click(object sender, EventArgs e)
        {
           Move themovies = new Move(); 
            themovies.Show();
        }

        private void fMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void picleft_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            if (Index > 0) Index--;
            else Index = list.Count- 1;
            pictureBox2.Image = Image.FromFile(@"..\\DataFiles\\"+list[Index]+".jpg");
            timer1.Start();
          
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            picright_Click(sender, e);
        }

        private void picright_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            if (Index < list.Count - 1)
                Index++;
            else Index = 0;
            pictureBox2.Image = Image.FromFile(@"..\\DataFiles\\" + list[Index] + ".jpg");
            pictureBox2.Refresh();
            timer1.Start();
        }

    
    }

}
