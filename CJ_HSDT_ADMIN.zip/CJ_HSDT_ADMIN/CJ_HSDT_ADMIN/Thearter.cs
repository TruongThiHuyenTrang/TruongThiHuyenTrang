﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CJ_HSDT_ADMIN
{
    public partial class Thearter : Form
    {
        int LEFT = 20;
        int TOP = 20;
        int WIDTH = 20;
        int dong, cot, x1, x2, y1, y2;

        private Font fnt = new Font("Candara", 10);
        public Thearter()
        {
            InitializeComponent();
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.BackColor = Color.White;
        }



    
        private void Thearter_Load(object sender, EventArgs e)
        {
            
            // Connect the Paint event of the PictureBox to the event handler method.
           // pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);

        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
              VeOVuong();
          //  Ve1();
    
        }

        private void bVe_Click(object sender, EventArgs e)
        {
            pictureBox1.Controls.Clear();
             dong = Int32.Parse(txtDong.Text);
             cot = Int32.Parse(txtCot.Text);
             x1 = LEFT + 2 * WIDTH - 3;
             x2 = x1 + WIDTH * cot;
             y1 = TOP + WIDTH - 3;
             y2 = y1 + WIDTH * dong;
            CheckBox box;
            for (int i = 0; i < dong; i++)
            {
                box = new CheckBox();
                box.Checked = true;
                box.Tag = i.ToString();
                box.Text = "" + (Char)('A' + i);
                box.AutoSize = true;
                box.Location = new Point(LEFT, i * WIDTH + y1 + 3);
                pictureBox1.Controls.Add(box);
            }
            for (int j = 0; j < cot; j++)
            {
                box = new CheckBox();
                box.Tag = j.ToString();
                box.Text = "";
                box.Checked = true;
                box.AutoSize = true;
                box.Location = new Point(j * WIDTH + x1 + 3, TOP);
                pictureBox1.Controls.Add(box);
            }
            VeOVuong();
         //   Ve1();
        }
        void VeOVuong()
        {

            Pen p = new Pen(Color.Green, 1);
            Graphics g = pictureBox1.CreateGraphics();


            for (int i = 0; i <= dong; i++) 
                       g.DrawLine(p, x1, y1 + i * WIDTH, x2, y1 + i * WIDTH);
                for (int j = 0; j <= cot; j++) 
                    g.DrawLine(p, x1 + j * WIDTH, y1, x1 + j * WIDTH, y2);

         //   pictureBox1.Refresh();   
           
        }
       
    }
}
